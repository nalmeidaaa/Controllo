import { urlImagemPatrimonio } from '../../services/imagemService.js';

export default function PatrimonioFormRow({ linha, onAtualizar, onRemover }) {
    const { idPatrimonio, nome, status, numeroPatrimonio, novo, previewFoto, caminhoImagem } = linha;

    const imagemAtual = previewFoto || urlImagemPatrimonio({ caminho_imagem: caminhoImagem });
    const inputId = `foto-patrimonio-${idPatrimonio || linha.chave}`;

    function handleFotoChange(e) {
        const file = e.target.files[0] || null;
        if (!file) {
            onAtualizar({ ...linha, arquivoFoto: null, previewFoto: null });
            return;
        }
        const reader = new FileReader();
        reader.onload = (ev) => onAtualizar({ ...linha, arquivoFoto: file, previewFoto: ev.target.result });
        reader.readAsDataURL(file);
    }

    return (
        <div className={`patrimonio-item-form ${novo ? 'patrimonio-novo' : ''}`}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <span style={{ fontSize: 12, color: novo ? 'var(--vermelho-principal)' : 'var(--texto-suave)', fontWeight: novo ? 600 : 500 }}>
                    {novo ? 'Novo patrimônio' : `ID: ${idPatrimonio || '—'}`}
                </span>
                <button
                    type="button"
                    className="btn-remover-patrimonio"
                    onClick={onRemover}
                    title="Remover"
                    aria-label="Remover patrimônio"
                >
                    ✕
                </button>
            </div>

            <div className="form-row" style={{ marginBottom: 10 }}>
                <div>
                    <label className="form-label-edit">Nome do Item <span className="required-mark">*</span></label>
                    <input
                        type="text" className="form-input-edit"
                        value={nome}
                        onChange={(e) => onAtualizar({ ...linha, nome: e.target.value })}
                        placeholder="Ex: Cadeira Pro"
                        style={linha.erro ? { borderColor: '#ef4444' } : undefined}
                    />
                    {linha.erro && <span className="form-error-edit">Informe um nome com pelo menos 3 caracteres.</span>}
                </div>
                <div>
                    <label className="form-label-edit">Status</label>
                    <select
                        className="form-input-edit"
                        value={status}
                        onChange={(e) => onAtualizar({ ...linha, status: e.target.value })}
                    >
                        <option value="Ok">Ok</option>
                        <option value="Pendente">Pendente</option>
                        <option value="Danificado">Danificado</option>
                        <option value="Manutenção">Manutenção</option>
                        <option value="Descartado">Descartado</option>
                    </select>
                </div>
            </div>

            <div className="form-group-edit" style={{ marginBottom: 10 }}>
                <label className="form-label-edit">Número do Patrimônio</label>
                <input
                    type="text" className="form-input-edit"
                    value={numeroPatrimonio || ''}
                    onChange={(e) => onAtualizar({ ...linha, numeroPatrimonio: e.target.value })}
                    placeholder="Ex: 2024-00123"
                    maxLength={20}
                />
            </div>

            <div className="form-group-edit" style={{ marginBottom: 0 }}>
                <label className="form-label-edit">{novo ? 'Foto' : 'Foto (substituir)'}</label>
                <div className="patrimonio-img-upload-row">
                    <div className="patrimonio-img-preview">
                        {imagemAtual ? (
                            <img src={imagemAtual} alt={`Prévia de ${nome || 'patrimônio'}`} />
                        ) : (
                            <span className="patrimonio-img-preview-placeholder">Sem foto</span>
                        )}
                    </div>
                    <div className="patrimonio-img-upload-controls">
                        <label className="btn-upload-imagem" htmlFor={inputId} style={{ width: 'fit-content' }}>
                            <ion-icon name="folder-open-outline" style={{ fontSize: '18px' }}></ion-icon>
                            Selecionar foto
                        </label>
                        <input
                            type="file" id={inputId} accept="image/*"
                            className="foto-input"
                            onChange={handleFotoChange}
                        />
                        {!novo && !imagemAtual && (
                            <small className="form-hint">Sem foto cadastrada.</small>
                        )}
                        {!novo && imagemAtual && !previewFoto && (
                            <small className="form-hint">A foto atual será mantida se nenhuma nova for selecionada.</small>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
